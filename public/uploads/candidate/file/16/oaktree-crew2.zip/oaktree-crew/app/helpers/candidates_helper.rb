module CandidatesHelper
end
